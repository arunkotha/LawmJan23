<?php

?>
<form action="http://localhost/mb/index.php/client/put/50" method="post">
    Name <input type="text" name="dname" value=""/>
    Price <input type="text" name="dprice" value=""/>
    Author <input type="text" name="dauthor" value=""/>
    <input type="submit" name="submit" value="submit"/>
</form>

