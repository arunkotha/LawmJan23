<?php
/**
 * Created by PhpStorm.
 * User: BHASHA
 * Date: 28/12/15
 * Time: 5:44 PM
 */

class MY_Composer
{
    function __construct()
    {
        include("./vendor/autoload.php");
    }
}