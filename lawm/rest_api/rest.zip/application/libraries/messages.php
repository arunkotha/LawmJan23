<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*class custom_error_messages
{
    public $errors = array(

    );
}*/

$custom_error_message['covenant_category_id'] = array(
    'required' => 'Covenant category required'
);


